// required when running on node.js
var mqtt = require('mqtt');

var led="off";

var client = mqtt.connect('mqtt://try:try@broker.shiftr.io', {
  clientId: 'javascript'
});

client.on('connect', function(){
  console.log('client has connected!');

  client.subscribe('M1/sensors/temp');
  // client.unsubscribe('/example');

  setInterval(function(){
    if (led=="on"){
        client.publish('/M1/sensors/led', 'off');
        led = "off";
    }else{
       client.publish('/M1/sensors/led', 'on');
       led = "on";
    }
    
  }, 1000);
});

client.on('message', function(topic, message) {
  console.log('new message:', topic, message.toString());
});