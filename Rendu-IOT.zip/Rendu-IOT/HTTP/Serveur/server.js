var express = require('express');
var fetch = require('node-fetch')

var app = express();

var ip = 'http://192.168.43.135'

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.header("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");

    next();
});

app.get('/exemple', function(req, res) {
    
    var temp = ''

    fetch('https://github.com/')
        .then(res => {return res.json();})
    console.log(temp)
    res.setHeader('Content-Type', 'text/plain');

    res.send('Vous êtes à l\'accueil');
    

});


app.get('/temp', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    fetch(ip+'/temp')
        .then(res => res.json())
        .then(json => res.send(json));
});

app.get('/led/on', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    fetch(ip+'/led/on')
        .then(res => res.json())
        .then(json => res.send(json));
});


app.get('/led/off', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    fetch(ip+'/led/off')
        .then(res => res.json())
        .then(json => res.send(json));
});



app.listen(8080);