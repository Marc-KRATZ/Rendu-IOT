
var test;
led = "OFF"



window.onload = function init() {

    var temp = document.getElementById('temp');

    test = document.getElementById('led')

    getTemp()

    
    setInterval(getTemp,1000);

    function getTemp(){
        let url = "http://localhost:8080/temp"
        fetch(url)
            .then((reponseJSON) => {
                reponseJSON.json()
                    .then((reponseJS) => {
                        console.log(reponseJS)
                        if (reponseJS.client == ""){
                            temp.innerHTML = "unknow";
                        }else{
                            temp.innerHTML = reponseJS.client;
                        }

                    });
            })
            .catch(function (err) {
                console.log(err);
                temp.innerHTML = "unknow";
            });
    }

    

}

function getLed(){
    if(led == "ON"){
        let url = "http://localhost:8080/led/off"
        led = "OFF"
        fetch(url).then((reponseJSON) => {
                reponseJSON.json()
                    .then((reponseJS) => {
                        console.log(reponseJS)
                        test.innerHTML = "OFF"
                    });
            })
            .catch(function (err) {
                console.log(err);
            });
    }else{
        let url = "http://localhost:8080/led/on"
        led = "ON"
        fetch(url).then((reponseJSON) => {
                reponseJSON.json()
                    .then((reponseJS) => {
                        console.log(reponseJS)
                        test.innerHTML = "ON"
                    });
            })
            .catch(function (err) {
                console.log(err);
            });
    }
}